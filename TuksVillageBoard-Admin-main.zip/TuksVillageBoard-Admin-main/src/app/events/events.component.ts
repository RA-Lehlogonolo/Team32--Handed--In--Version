import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  validateForm: any;
  isAddItemVisible: boolean;
  isUpdateItemVisible: boolean;
  isDeleteItemVisible: boolean;
  constructor(
    private fb: FormBuilder,
    private notification: NzNotificationService,
    ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      description: [null, [Validators.required]],
      name: [null, [Validators.required]],
      aType: [null, [Validators.required]],
      date: [null, [Validators.required]],


    });
  }

  showAddItemModal(): void {
    this.isAddItemVisible = true;

  }

  handleOkAddItem(): void {
    this.isAddItemVisible = false;


  }

  handleCancelAddItem(): void {
    this.isAddItemVisible = false;


  }

  showUpdateItemModal(): void {
    this.isUpdateItemVisible = true;
  }

  handleOkUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  handleCancelUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  showDeleteItemModal(): void {
    this.isDeleteItemVisible = true;
  }

  handleOkDeleteItem(): void {
    this.isDeleteItemVisible = false;
    this.notification.create('success','','Successfully deleted event!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );

  }
  handleCancelDeleteItem(): void {
    this.isDeleteItemVisible = false;
  }
  confirm(): void {
    this.notification.create('success','','Successfully updated event!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isUpdateItemVisible = false;


  }

  confirmAdd(): void {
    this.notification.create('success','','Successfully added event!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isAddItemVisible = false;

  }

  listOfData: any[] = [
    {date:"2021-06-29 13:00",
      item: "TuksVillage Seminar",
      itemType: "Educational",
    },
    {
      date:"2021-06-24 12:00",
      item: "Tuks Sports Day",
      itemType: "Sport",
    },
    {
      date:"2021-06-19 11:00",
      item: "Tuks Musical Event",
      itemType: "Music",
    },

    

  ];

}
