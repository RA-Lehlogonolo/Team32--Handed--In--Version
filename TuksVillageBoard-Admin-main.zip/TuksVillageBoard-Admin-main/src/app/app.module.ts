import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IconsProviderModule } from './icons-provider.module';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { en_US } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { DemoNgZorroAntdModule } from './ng-zorro-antd.module';
import { ResidencesComponent } from './residences/residences.component';
import { LoginComponent } from './login/login.component';
import { RoomsComponent } from './rooms/rooms.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { UserRolesComponent } from './user-roles/user-roles.component';
import { UsersComponent } from './users/users.component';
import { DisciplinaryHearingComponent } from './disciplinary-hearing/disciplinary-hearing.component';
import { VisitationApplicationsComponent } from './visitation-applications/visitation-applications.component';
import { MenuTypeComponent } from './menu-type/menu-type.component';
import { MealTypeComponent } from './meal-type/meal-type.component';
import { ItemsComponent } from './items/items.component';
import { ItemTypeComponent } from './item-type/item-type.component';
import { MenuComponent } from './menu/menu.component';
import { EventsComponent } from './events/events.component';
import { EventTypeComponent } from './event-type/event-type.component';
import { ProductComponent } from './product/product.component';
import { ProductTypeComponent } from './product-type/product-type.component';
import { MaintenancerequestTypeComponent } from './maintenancerequest-type/maintenancerequest-type.component';
import { RoomInspectionComponent } from './room-inspection/room-inspection.component';
import { MaintenanceRequestComponent } from './maintenance-request/maintenance-request.component';
import { HealthInspectionResultsComponent } from './health-inspection-results/health-inspection-results.component';
import { OrdersComponent } from './orders/orders.component';
import { HighlightPipe } from './highlight.pipe';
import { HealthInspectionReportComponent } from './health-inspection-report/health-inspection-report.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { StockLevelReportComponent } from './stock-level-report/stock-level-report.component';
import { VisitationReportComponent } from './visitation-report/visitation-report.component';
import { DisciplinaryHearingReportComponent } from './disciplinary-hearing-report/disciplinary-hearing-report.component';
import { DaysComponent } from './days/days.component';

registerLocaleData(en);

@NgModule({
  declarations: [
    AppComponent,
    ResidencesComponent,
    LoginComponent,
    RoomsComponent,
    AnnouncementsComponent,
    UserRolesComponent,
    UsersComponent,
    DisciplinaryHearingComponent,
    VisitationApplicationsComponent,
    MenuTypeComponent,
    MealTypeComponent,
    ItemsComponent,
    ItemTypeComponent,
    MenuComponent,
    EventsComponent,
    EventTypeComponent,
    ProductComponent,
    ProductTypeComponent,
    MaintenancerequestTypeComponent,
    RoomInspectionComponent,
    MaintenanceRequestComponent,
    HealthInspectionResultsComponent,
    OrdersComponent,
    HighlightPipe,
    HealthInspectionReportComponent,
    SalesReportComponent,
    StockLevelReportComponent,
    VisitationReportComponent,
    DisciplinaryHearingReportComponent,
    DaysComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    IconsProviderModule,
    NzLayoutModule,
    NzMenuModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    DemoNgZorroAntdModule,
    ReactiveFormsModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }],
  bootstrap: [AppComponent]
})
export class AppModule { }
