import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {
  validateForm: any;
  isAddItemVisible: boolean;
  isUpdateItemVisible: boolean;
  isDeleteItemVisible: boolean;
  constructor(
    private fb: FormBuilder,
    private notification: NzNotificationService,
    ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      description: [null, [Validators.required]],
      name: [null, [Validators.required]],
      aType: [null, [Validators.required]],
      campus: [null, [Validators.required]],


    });
  }

  showAddItemModal(): void {
    this.isAddItemVisible = true;

  }

  handleOkAddItem(): void {
    this.isAddItemVisible = false;


  }

  handleCancelAddItem(): void {
    this.isAddItemVisible = false;


  }

  showUpdateItemModal(): void {
    this.isUpdateItemVisible = true;
  }

  handleOkUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  handleCancelUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  showDeleteItemModal(): void {
    this.isDeleteItemVisible = true;
    this.notification.create('success','','Successfully deleted item!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  }

  handleOkDeleteItem(): void {
    this.isDeleteItemVisible = false;


  }
  handleCancelDeleteItem(): void {
    this.isDeleteItemVisible = false;
  }

  confirm(): void {
    this.notification.create('success','','Successfully updated item!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isUpdateItemVisible = false;


  }

  confirmAdd(): void {
    this.notification.create('success','','Successfully added item!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isAddItemVisible = false;

  }


  listOfData: any[] = [
    {
      item: "Crumbed chicken strips",
      itemType: "Protein",
    },
    {

      item: "Tortilla",
      itemType: "Starch",
    },
    {

      item: "Chicken Leg",
      itemType: "Protein",
    },

    {

      item: "Rice",
      itemType: "Starch",
    }, 
    {

      item: "French Salad & dressing",
      itemType: "Salad",
    },
    {

      item: "Greek Salad & dressing",
      itemType: "Salad",
    },
    {

      item: "Peas",
      itemType: "Vegetable",
    },
    {

      item: "Sea Food Sauce",
      itemType: "Sauce",
    },
    {

      item: "Creamed Spinach",
      itemType: "Vegetable",
    },
    {

      item: "Cheese Sauce",
      itemType: "Sauce",
    },
    

  ];


}
