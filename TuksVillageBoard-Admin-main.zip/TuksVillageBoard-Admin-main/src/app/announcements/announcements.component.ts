import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css']
})
export class AnnouncementsComponent implements OnInit {
  isAddAnnouncementsVisible: boolean;
  isUpdateAnnouncementsVisible: boolean;
  isDeleteAnnouncementsVisible: boolean;
  validateForm!: FormGroup;


  constructor(
    private fb: FormBuilder,
    private notification: NzNotificationService
    
    ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      description: [null, [Validators.required]],
      name: [null, [Validators.required]],
      aType: [null, [Validators.required]],
      campus: [null, [Validators.required]],


    });
  }


  showAddAnnouncementsModal(): void {
    this.isAddAnnouncementsVisible = true;

  }

  handleOkAddAnnouncements(): void {
    this.isAddAnnouncementsVisible = false;
    this.notification.create('success','','Successfully added announcement!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  

  }

  handleCancelAddAnnouncements(): void {
    this.isAddAnnouncementsVisible = false;


  }

  showUpdateAnnouncementsModal(): void {
    this.isUpdateAnnouncementsVisible = true;
  }

  handleOkUpdateAnnouncements(): void {
    this.isUpdateAnnouncementsVisible = false;
    this.notification.create('success','','Successfully updated announcement!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  }

  handleCancelUpdateAnnouncements(): void {
    this.isUpdateAnnouncementsVisible = false;
  }

  showDeleteAnnouncementsModal(): void {
    this.isDeleteAnnouncementsVisible = true;
  }

  handleOkDeleteAnnouncements(): void {
    this.isDeleteAnnouncementsVisible = false;
    this.notification.create('success','','Successfully deleted announcement!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );

  }
  handleCancelDeleteAnnouncements(): void {
    this.isDeleteAnnouncementsVisible = false;
  }



  cancel(): void {

  }

  confirm(): void {
    this.notification.create('success','','Successfully updated announcement!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isUpdateAnnouncementsVisible = false;


  }

  confirmAdd(): void {
    this.notification.create('success','','Successfully added announcement!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isAddAnnouncementsVisible = false;


  }






  listOfData: any[] = [
    {
      announcementType: "General",
      announcementName: "Loud Music !",
      announcementDescription: "Please avoid playing loud music after 10 PM",
      date:"2021-06-26",
    },
   {    
      announcementType: "Electrical",
      announcementName: "Electrical issues",
      announcementDescription: "Electrical issues are being attended in block A",
      date:"2021-06-21",
 
    },
   
  ];

}
