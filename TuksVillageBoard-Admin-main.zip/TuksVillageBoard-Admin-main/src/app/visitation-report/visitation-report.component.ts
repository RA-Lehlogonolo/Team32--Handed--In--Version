import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitation-report',
  templateUrl: './visitation-report.component.html',
  styleUrls: ['./visitation-report.component.css']
})
export class VisitationReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  listOfData: any[] = [
    {
      Date: "2020-07-18 23:16",
      Start: "2021-05-26",
      End: "2021-08-23",
      Reason: "I have to attend a relative's funeral",
      Status: "Pending",
      Student: "John Doe"

    },
    {
      Date: "2021-03-11 21:38",
      Start: "2021-10-01",
      End: "2021-11-01",
      Reason: " I have to attend to a family emergency,",
      Status: "Approved",
      Student: "Jim Doe"

    },
    {
      Date: "2021-03-25 21:40",
      Start: "2021-06-17",
      End: "2020-12-26",
      Reason: "I miss home !",
      Status: "Rejected",
      Student: "Jim Doe"
    },
  ];
}
